#ifndef UARM_LIBUARM_H
#define UARM_LIBUARM_H

void tprint(const char *s);

extern unsigned int LDST(void *addr);

#endif //UARM_LIBURAM_H
