#ifndef TYPES_H
#define TYPES_H

/* temporary definition for phase1 */
typedef void *state_t;

#endif
